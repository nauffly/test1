/**
 * Javi config — fill these in after you create your Supabase project.
 * 1) Go to Supabase project → Settings → API
 * 2) Copy:
 *    - Project URL  → SUPABASE_URL
 *    - anon public key → SUPABASE_ANON_KEY
 */
window.JAVI_CONFIG = {
  SUPABASE_URL: "https://xdvmrudqzfhmulxycbcf.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_ZpZXH3Xtvdo3BEALybpczg_g-m29lVT"
};
